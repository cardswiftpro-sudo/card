/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.za.tut.bl;

import ac.za.tut.entity.FieldAgent;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Student
 */
@Stateless
public class FieldAgentFacade extends AbstractFacade<FieldAgent> implements FieldAgentFacadeLocal {

    @PersistenceContext(unitName = "TextSpectaclesEJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public FieldAgentFacade() {
        super(FieldAgent.class);
    }

    @Override
    public List<FieldAgent> findFieldAgentWithSpecificGender(String gender) {

        Query query = em.createQuery("SELECT F FROM FieldAgent F WHERE F.gender=:gender");
        query.setParameter("gender", gender);

        return (List<FieldAgent>) query.getResultList();
    }

    @Override
    public List<FieldAgent> findMarriedFieldAgentWithSpecificGender(String gender) {

        Query query = em.createQuery("SELECT F FROM FieldAgent F WHERE F.gender=:gender AND F.maritalStatus=:maritalStatus");
        query.setParameter("gender", gender);
        query.setParameter("maritalStatus", "MARRIED");

        return (List<FieldAgent>) query.getResultList();
    }

    @Override
    public List<FieldAgent> findFieldAgentWithSpecificGenderAndAgeRange(String gender, Integer startAge, Integer maxAge) {
        Query query = em.createQuery("SELECT F FROM FieldAgent F WHERE F.gender=:gender AND F.age >=:startAge AND F.age<=:maxAge");
        query.setParameter("gender", gender);
        query.setParameter("startAge", startAge);
        query.setParameter("maxAge", maxAge);

        return (List<FieldAgent>) query.getResultList();
    }

    @Override
    public FieldAgent findOldesFieldAgent() {

        Query query = em.createQuery("SELECT F FROM FieldAgent F WHERE F.age =(SELECT MAX(F.age) FROM FieldAgent F)");

        return (FieldAgent) query.getSingleResult();
    }

}
