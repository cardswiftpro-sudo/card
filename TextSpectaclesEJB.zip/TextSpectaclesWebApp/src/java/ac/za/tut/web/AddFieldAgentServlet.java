/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ac.za.tut.web;

import ac.za.tut.bl.FieldAgentFacadeLocal;
import ac.za.tut.entity.FieldAgent;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Student
 */
public class AddFieldAgentServlet extends HttpServlet {
    
    @EJB
    private FieldAgentFacadeLocal fal;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name =  request.getParameter("name");
        Long id =  Long.parseLong(request.getParameter("id"));
        Integer age =  Integer.parseInt(request.getParameter("age"));
        String gender =  request.getParameter("gender");
        String date =  request.getParameter("dob");
        SimpleDateFormat formatedDate = new SimpleDateFormat("yyyy/mm/dd");
        Date dob = new Date();
        
        try {
             dob= formatedDate.parse(date);
        } catch (ParseException ex) {
            Logger.getLogger(AddFieldAgentServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String  maritalStatus = request.getParameter("marital_status");
        
        FieldAgent fieldAgent = new FieldAgent();
        
        fieldAgent.setName(name);
        fieldAgent.setId(id);
        fieldAgent.setAge(age);
        fieldAgent.setGender(gender);
        fieldAgent.setDob(dob);
        fieldAgent.setCreatedAt(new Date());
        fieldAgent.setMaritalStatus(maritalStatus);
        
        fal.create(fieldAgent);
        RequestDispatcher rd = request.getRequestDispatcher("outcome-page.html");
        rd.forward(request, response);

    }

}
