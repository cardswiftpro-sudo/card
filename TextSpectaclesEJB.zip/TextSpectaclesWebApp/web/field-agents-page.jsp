<%-- 
    Document   : field-agents-page
    Created on : 05 May 2026, 21:07:11
    Author     : Student
--%>

<%@page import="ac.za.tut.entity.FieldAgent"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Hello World!</h1>

        <%
            List<FieldAgent> fieldAgents = (List<FieldAgent>) request.getAttribute("fieldAgents");
        %>
        
        <p><%=fieldAgents.toString()%></p>
    </body>
</html>
