/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ac.za.tut.web;

import ac.za.tut.bl.FieldAgentFacadeLocal;
import ac.za.tut.entity.FieldAgent;
import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Enough
 */
public class GetFieldAgentOfSpecificGenderAndAgeRangeServlet extends HttpServlet {

    
    @EJB
    private FieldAgentFacadeLocal fal;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String gender = request.getParameter("gender");
        Integer startAge = Integer.parseInt(request.getParameter("start_age"));
        Integer maxAge = Integer.parseInt(request.getParameter("max_age"));
        
        List<FieldAgent> fieldAgents =  fal.findFieldAgentWithSpecificGenderAndAgeRange(gender, startAge, maxAge);
        
        request.setAttribute("fieldAgents",fieldAgents);

        RequestDispatcher rd = request.getRequestDispatcher("field-agents-with-specific-gender-and-age-range.jsp");
        rd.forward(request, response);
    }



}
