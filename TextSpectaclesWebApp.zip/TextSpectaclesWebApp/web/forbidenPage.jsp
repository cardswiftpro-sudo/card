<%-- 
    Document   : forbidenPage
    Created on : 12 May 2026, 22:02:55
    Author     : Enough
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Forbidden Page</title>
    </head>
    <body>
        <h1>Forbidden</h1>
        
        <p>You Are not allowed to access this page.</p>
    </body>
</html>
