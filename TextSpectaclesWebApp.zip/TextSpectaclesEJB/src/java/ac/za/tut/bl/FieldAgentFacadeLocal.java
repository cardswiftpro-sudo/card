/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ac.za.tut.bl;

import ac.za.tut.entity.FieldAgent;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Enough
 */
@Local
public interface FieldAgentFacadeLocal {

    void create(FieldAgent fieldAgent);

    void edit(FieldAgent fieldAgent);

    void remove(FieldAgent fieldAgent);

    FieldAgent find(Object id);

    List<FieldAgent> findAll();

    List<FieldAgent> findRange(int[] range);

    int count();

    public List<FieldAgent> findFieldAgentWithSpecificGender(String gender);
    
    List<FieldAgent> findMarriedFieldAgentWithSpecificGender(String gender);
    
    List<FieldAgent> findFieldAgentWithSpecificGenderAndAgeRange(String gender,Integer startAge,Integer maxAge);
    
    FieldAgent findOldesFieldAgent();
    
    
}
