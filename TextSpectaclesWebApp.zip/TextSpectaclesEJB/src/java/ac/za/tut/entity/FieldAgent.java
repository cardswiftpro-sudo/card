/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.za.tut.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Enough
 */
@Entity
public class FieldAgent implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    private Long id;
    
    private String name;
    private String gender;
    private String maritalStatus;
    
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date dob;
    private Integer age;
    
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    public FieldAgent() {
    }

    public FieldAgent(Long id, String name, String gender, String maritalStatus, Date dob, Integer age, Date createdAt) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.maritalStatus = maritalStatus;
        this.dob = dob;
        this.age = age;
        this.createdAt = createdAt;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
    
    
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FieldAgent)) {
            return false;
        }
        FieldAgent other = (FieldAgent) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "FieldAgent{" + "id=" + id + ", name=" + name + ", gender=" + gender + ", maritalStatus=" + maritalStatus + ", dob=" + dob + ", age=" + age + ", createdAt=" + createdAt + '}';
    }
    
}
